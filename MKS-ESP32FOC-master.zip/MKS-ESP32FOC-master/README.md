# MKS-ESP32FOC

ESP32 FOC is an integrated motherboard designed based on simple FOC, which supports dual motor control.
